# Development Constitution

- **Status:** PROPOSED — owner approval required
- **Version:** 1.0
- **Date:** 2026-11-19
- **Scope:** all code, assets, tools, tests, documentation and AI-assisted work in this repository.

## 1. Mission

Build a Pokémon-inspired 3D world that supports two complementary experiences:

1. observing a living, autonomous ecosystem;
2. exploring and interacting with that world as a trainer.

The project is developed on the owner's PC. Performance decisions must be measured on the actual development machine. Do not invent a broad minimum-hardware target.

The current development priority is the explorable spherical world. The first playable milestone comes before broad ecosystem, combat, multiplayer or content expansion.

## 2. Authority hierarchy

When instructions disagree, use this order:

1. Explicit project-owner decision recorded in `DECISION_REGISTER.md`.
2. This constitution for process and governance.
3. `ARCHITECTURE_BASELINE_V2.md` for architecture and dependency rules.
4. `MASTER_ROADMAP_V2.md` for sequencing and release scope.
5. The owning domain document for domain behaviour and data.
6. An approved work-package specification for its bounded implementation.
7. Implementation and tests as evidence of actual behaviour.

Code does not automatically overrule documentation. Old documents, old chat messages, generated reports and comments do not overrule a newer approved decision.

If two approved sources conflict, stop the affected work, record the conflict and request a decision. Never silently reconcile it.

## 3. Status vocabulary

Every feature, document and work package must use one of these states:

- `IDEA`: unreviewed possibility.
- `PROPOSED`: scoped proposal awaiting owner approval.
- `APPROVED`: scope and design approved; implementation may begin after the plan milestone.
- `IN_PROGRESS`: implementation underway.
- `BLOCKED`: a named dependency or defect prevents progress.
- `IMPLEMENTED`: source changes exist; validation is not necessarily complete.
- `VALIDATED`: required automated and manual evidence passed.
- `ACCEPTED`: QA review passed and project owner approved.
- `DEPRECATED`: replacement exists; migration/removal remains.
- `REMOVED`: deleted after dependency and reference checks.

Never use `DONE` as a substitute for these states.

## 4. Non-negotiable development rules

### 4.1 One work package, one outcome

- One work package must deliver one independently describable capability or one bounded technical correction.
- Split work if it has multiple independent outputs, different validation environments, or more than one major architectural dependency.
- Do not add opportunistic refactors, unrelated bug fixes or future-proofing to an implementation.
- Record out-of-scope discoveries in the queue as separate work.

### 4.2 Specification before implementation

No substantial implementation starts until its work package is `APPROVED` and its plan milestone has been committed/pushed on the working branch.

The specification must identify:
- purpose and user-visible result;
- owner module;
- dependencies and exact contracts used;
- files expected to change;
- data inputs/outputs and units;
- deterministic inputs and seed policy;
- independent preview method;
- automated tests;
- integration tests;
- manual visual checks;
- performance measurements;
- failure cases;
- acceptance criteria;
- exclusions and rollback/removal plan.

### 4.3 Inspect before editing

Before changing code:
1. inspect the current repository version;
2. read the owning domain and architecture documents;
3. locate declarations of every referenced type and interface;
4. inspect all callers, consumers, tests, assets and serialization references;
5. check assembly boundaries and `.meta` GUID implications;
6. state the proposed change scope;
7. confirm that the feature can be tested without relying solely on the full game scene.

Never infer an API or namespace from a filename or folder name.

### 4.4 Module-first implementation

Implement and validate the smallest useful module in isolation before wiring it into the full game.

The required sequence is:
1. pure logic and data contracts;
2. module-level EditMode tests;
3. module preview or sandbox;
4. module validation;
5. adapter/integration;
6. integration tests;
7. full-game visual and PlayMode validation;
8. QA and owner acceptance.

A known integration failure must not be hidden by changing the module's internal rules without evidence.

### 4.5 No manual repetitive setup

Prefer code-driven, repeatable and idempotent tooling for:
- creating or updating ScriptableObjects;
- prefab generation and validation;
- material and shader setup;
- scene/bootstrap creation;
- test fixtures and preview scenes;
- asset import and registration;
- batch diagnostics.

Manual Inspector setup is allowed for a small number of stable references or values intentionally designed for human tuning. Document why it is manual.

### 4.6 No silent architecture expansion

A work package may not:
- create a new cross-domain dependency;
- move ownership of data or behaviour;
- introduce a service locator/global mutable state;
- add a package or framework;
- change public interfaces or serialized schemas;
- change world-generation semantics;
- add a second implementation of an existing responsibility;

without an approved change proposal and updated architecture/decision records.

### 4.7 No premature optimization

Measure first. Record baseline time, memory, allocations, object count and target test scale where relevant. Optimize only against a demonstrated bottleneck. Do not introduce pooling, streaming, ECS, jobs, GPU instancing or complex LOD solely because they may be useful later.

### 4.8 Full-file and patch discipline

Follow the project owner's current delivery preference:
- For ordinary project files, provide complete corrected files when requested.
- For the VR HackWand project only, provide changed functions/lines.
- Never assume the owner edited a file unless explicitly stated or verified from the current repository.
- Do not overwrite user changes without identifying them.

## 5. Mandatory validation gates

A feature cannot advance past a gate with an unexplained failure.

| Gate | Required evidence |
|---|---|
| G0 — Scope | Approved work package, owner module, dependencies, acceptance criteria |
| G1 — Static integrity | Correct ownership, namespaces, references, no forbidden dependency |
| G2 — Isolated logic | EditMode tests and deterministic fixture where applicable |
| G3 — Isolated preview | Preview/sandbox result, reproducible inputs, diagnostics |
| G4 — Integration | Contract tests and integration test in intended composition root |
| G5 — Runtime | PlayMode/manual validation in the real target scene |
| G6 — Quality | Performance baseline, regression checks, documentation updated |
| G7 — Acceptance | Independent QA report and explicit owner approval |

A gate may be `N/A` only with a written reason in the work package. `BLOCKED` is not `PASS`.

## 6. Definition of Done

A work package is `ACCEPTED` only when:
- implementation matches the approved specification;
- all applicable tests pass;
- independent module preview passes;
- integration and target-scene checks pass;
- no new compiler errors or unresolved critical warnings are introduced;
- diagnostics and failure cases are understandable;
- performance measurements are recorded where relevant;
- documentation, feature index and decision records are updated;
- obsolete code/docs are either migrated or explicitly tracked;
- QA has reviewed the evidence;
- the project owner has approved the result;
- the exact commit message is prepared.

A feature that compiles but has not been run in Unity is `IMPLEMENTED`, not `VALIDATED`.

## 7. Git and checkpoint rules

Follow `GIT_WORKFLOW.md`.

- Use the same working branch for plan and implementation milestones.
- Plan/specification milestone must be pushed before implementation.
- Implementation milestone follows source changes and available checks.
- QA corrections use a separate corrective commit.
- After each validated feature, provide the exact commit message.
- If work stops early, provide a checkpoint commit message describing exactly what is implemented, what remains, which tests were not run, and the next objective.
- Every commit uses Conventional Commits and the mandatory `Agent: <ID>` footer.
- Corrective commits are allowed; milestones are checkpoints, not a two-commit limit.

## 8. Cleanup is controlled migration

Non-compliant code is not automatically deleted. First classify it as:
- duplicate;
- obsolete;
- wrong ownership;
- dead/unreferenced;
- valid but not yet compliant;
- required compatibility layer;
- uncertain.

Before removal, identify references, serialized assets, scene usage, tests, public APIs, `.meta` GUIDs and documentation links. Replace or migrate first, validate, then remove. See `DEPRECATION_AND_CLEANUP_POLICY.md`.

## 9. Communication contract for AI agents

At the start of a work package, report:
- work package ID and status;
- intended outcome;
- owning module;
- dependencies;
- exact scope and exclusions;
- planned tests and preview.

During work:
- distinguish verified facts from assumptions;
- report blockers immediately;
- do not claim tests that were not run;
- do not change scope without approval.

At handoff, report:
- files created/modified/deleted;
- implementation status;
- tests run and exact results;
- tests not run and why;
- manual Unity steps still required;
- known limitations;
- documentation changes;
- next work package;
- commit message.

## 10. Change control

Changes to this constitution, architecture baseline, release gates or roadmap require:
1. a change proposal explaining why;
2. impact analysis;
3. explicit owner approval;
4. update to the decision register and changelog;
5. migration of affected documents and work packages.

The goal is stability, not bureaucracy: small local implementation details may evolve inside the approved boundaries without changing the constitution.
