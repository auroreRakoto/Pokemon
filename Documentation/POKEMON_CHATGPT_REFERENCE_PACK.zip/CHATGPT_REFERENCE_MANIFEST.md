# Pokémon — ChatGPT Reference Pack

- **Purpose:** let the ChatGPT Project consult stable engineering references without importing the complete Unity repository.
- **Source snapshot:** `Pokemon-clean.zip` supplied in this conversation.
- **Snapshot date in project audit:** 2026-11-19.
- **Status:** reference snapshot; not proof that the live Unity repository is unchanged.
- **Unity source of truth:** the Git repository.

## How to use

Upload the contents of this pack (or its ZIP) as Project files in the ChatGPT Pokémon project. Paste `CHATGPT_PROJECT_INSTRUCTIONS.md` into the ChatGPT Project instructions. For architecture, governance, roadmap and domain questions, consult these files first. For implementation questions, inspect the current code/assets from the current repository/archive before making claims about actual implementation.

## Separation of responsibilities

1. `UNITY_SOURCE_SNAPSHOT/` contains copies of selected Markdown sources from the Unity repository snapshot. These are mirrors for reference, not independent authorities.
2. `PROPOSED_STANDARDS/` contains proposed new standards created for ENG-001. All remain `PROPOSED` until owner approval and integration into the Unity repository.
3. `CHATGPT_PROJECT_INSTRUCTIONS.md` governs assistant workflow. It is not a replacement for the Unity repository's technical documentation.

## Synchronization rule

The Unity Git repository is canonical. When a source document changes and is approved, update the corresponding ChatGPT reference copy in the same documentation-maintenance cycle. Record the repository commit/hash and sync date in the ChatGPT Project changelog or reference manifest. If a ChatGPT copy is older or conflicts with the live repository, treat the live approved Unity source as authoritative and request the current file when needed. Never infer that a reference copy is current merely because it is attached.

## Important preserved decisions

- DEC-007 dedicated-server/server-authoritative direction is preserved; near-term local prototype scope does not cancel it.
- The spherical-world architecture candidate remains a proposal unless the decision register says otherwise.
- The first world prototype remains focused on spherical terrain, player movement and inspection.
- WORLD-011 is approved; initial placement scope is deterministic spherical placement for Plains and Forest only. Verify current work package and repository state before claiming status.

## Files included

- Selected governance, architecture, domain, engineering, test and AI instruction documents from the Unity snapshot.
- Current WORLD-011 audit and scope documents.
- Proposed standards and project instructions.

## Missing source files

- None from the selected list.
