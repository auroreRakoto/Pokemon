# Owner-operated workflow update — ENG-001 addendum

Status: PROPOSED documentation deliverable. No Unity repository was modified by the assistant.

## Files in this package

- `Documentation/00_GOVERNANCE/DEVELOPMENT_CONSTITUTION.md` — complete proposed constitution with the no-live-access and owner-operated workflow rules.
- `Documentation/00_GOVERNANCE/GIT_WORKFLOW.md` — copy of the supplied repository workflow, augmented with owner-run Git commands.
- `Documentation/03_ENGINEERING/EDITOR_TOOLING_AND_UI_STANDARD.md` — complete proposed tooling standard with Unity/Blender runbook requirements.
- `CHATGPT_PROJECT/CHATGPT_PROJECT_INSTRUCTIONS.md` — updated instructions to paste into ChatGPT Project settings.
- `CHATGPT_PROJECT/CHATGPT_REFERENCE_MANIFEST.md` — updated reference-pack note.

## Apply in the Unity repository

1. Open a terminal at the Unity repository root.
2. Run `git status --short --branch` and preserve any unrelated local changes.
3. Back up the current versions of the three repository documents listed above.
4. Copy the two files under `Documentation/00_GOVERNANCE/` and the file under `Documentation/03_ENGINEERING/` to the matching paths.
5. Review all three diffs. These proposed standards still require owner approval and reconciliation with existing approved documents; do not silently replace approved policy if the owner has not approved this migration.
6. Paste `CHATGPT_PROJECT/CHATGPT_PROJECT_INSTRUCTIONS.md` into the ChatGPT Project instructions if desired. Upload the manifest as a reference file if maintaining the pack.
7. Run:

```bash
git diff --check
git status --short
git diff -- Documentation/00_GOVERNANCE/DEVELOPMENT_CONSTITUTION.md Documentation/00_GOVERNANCE/GIT_WORKFLOW.md Documentation/03_ENGINEERING/EDITOR_TOOLING_AND_UI_STANDARD.md
```

8. After explicit approval, stage only these intended files, commit and push:

```bash
git add Documentation/00_GOVERNANCE/DEVELOPMENT_CONSTITUTION.md Documentation/00_GOVERNANCE/GIT_WORKFLOW.md Documentation/03_ENGINEERING/EDITOR_TOOLING_AND_UI_STANDARD.md
git diff --cached --check
git diff --cached
git commit -m "docs(workflow): define owner-operated Unity and Blender handoff" -m "Agent: DOC"
git push
```

9. Send back the commit hash and any conflicts/output. The assistant has not run these commands.

## Operating rule for future feature work

For each approved work package, the assistant will deliver exact files and paths, followed by an ordered runbook for Unity and/or Blender, file transformations, expected results, validation evidence to return, rollback notes and owner-run Git commands. The owner applies and tests the files locally. Checks requiring Unity, Blender or the target PC remain `OWNER TO RUN` / `NOT RUN` until evidence is returned.
