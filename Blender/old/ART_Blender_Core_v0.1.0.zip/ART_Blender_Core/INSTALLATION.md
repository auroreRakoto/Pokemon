# Installation du package ART Blender

1. Décompresser l'archive.
2. Copier le dossier `Blender/` dans la racine du dépôt Pokémon.
3. Si `Blender/` existe déjà, fusionner les dossiers sans supprimer les fichiers existants.
4. Vérifier que le chemin final est `<repo>/Blender/_core/__init__.py`.
5. Ouvrir Blender, passer dans l'espace Scripting et exécuter un script asset qui importe `_core`.

Cette livraison fournit uniquement la bibliothèque commune. Elle ne synchronise pas encore les FBX dans Unity.
TOOLS doit fournir la commande Unity de handoff séparée, conformément à `ART-001_TOOLS_REVIEW.md`.
